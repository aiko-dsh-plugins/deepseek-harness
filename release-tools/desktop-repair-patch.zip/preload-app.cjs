let electron = require("electron");
//#region lib/types/ipc.js
/** Typed preload operations exposed only by the Electron shell. */
/** IPC channel names kept private to the desktop application bundle. */
const DESKTOP_IPC = {
	localeGet: "dsh-desktop:locale-get",
	pluginsList: "dsh-desktop:plugins-list",
	pluginsAdd: "dsh-desktop:plugins-add",
	pluginsRemove: "dsh-desktop:plugins-remove",
	pluginsUpdate: "dsh-desktop:plugins-update",
	marketList: "dsh-desktop:market-list",
	marketHostVersion: "dsh-desktop:market-host-version",
	marketRequest: "dsh-desktop:market-request",
	updatesCheck: "dsh-desktop:updates-check",
	updatesInstall: "dsh-desktop:updates-install",
	updatesState: "dsh-desktop:updates-state"
};
//#endregion
//#region lib/types/preload-app.js
/** Minimal marker that selects the desktop custom-protocol API carrier. */
electron.contextBridge.exposeInMainWorld("dshDesktop", {
	protocolVersion: 1,
	market: {
		protocolVersion: 1,
		list: () => electron.ipcRenderer.invoke(DESKTOP_IPC.marketList),
		hostVersion: () => electron.ipcRenderer.invoke(DESKTOP_IPC.marketHostVersion),
		request: (request) => electron.ipcRenderer.invoke(DESKTOP_IPC.marketRequest, request)
	}
});
//#endregion
